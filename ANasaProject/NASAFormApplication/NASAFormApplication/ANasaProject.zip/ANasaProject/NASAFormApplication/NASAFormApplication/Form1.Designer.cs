﻿namespace NASAFormApplication

{

    partial class Form1

    {

        /// <summary>

        /// Required designer variable.

        /// </summary>

        private System.ComponentModel.IContainer components = null;



        /// <summary>

        /// Clean up any resources being used.

        /// </summary>

        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>

        protected override void Dispose(bool disposing)

        {

            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }



        #region Windows Form Designer generated code



        /// <summary>

        /// Required method for Designer support - do not modify

        /// the contents of this method with the code editor.

        /// </summary>

        private void InitializeComponent()

        {
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.goalMissionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.extraQuestionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.startButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.heightOfLaunchText = new System.Windows.Forms.Label();
            this.heightOfLaunchBox = new System.Windows.Forms.TextBox();
            this.speedOutputText = new System.Windows.Forms.Label();
            this.speedOutputBox = new System.Windows.Forms.TextBox();
            this.launchAngleOutputText = new System.Windows.Forms.Label();
            this.launchAngleBoxOutputBox = new System.Windows.Forms.TextBox();
            this.massOfPodText = new System.Windows.Forms.Label();
            this.massOfPodBox = new System.Windows.Forms.TextBox();
            this.totalAverageForceText = new System.Windows.Forms.Label();
            this.totalAverageForceBox = new System.Windows.Forms.TextBox();
            this.groundContactText = new System.Windows.Forms.Label();
            this.groundContactBox = new System.Windows.Forms.TextBox();
            this.successfulDeliveryText = new System.Windows.Forms.Label();
            this.sucessfulDeliveryBox = new System.Windows.Forms.TextBox();
            this.dynamicLabel = new System.Windows.Forms.Label();
            this.buttonPanel = new System.Windows.Forms.Panel();
            this.speedText = new System.Windows.Forms.Label();
            this.speedBox = new System.Windows.Forms.TextBox();
            this.dropHeightBox = new System.Windows.Forms.TextBox();
            this.dropHeightText = new System.Windows.Forms.Label();
            this.backgroundPanel = new System.Windows.Forms.Panel();
            this.launchAngleBox = new System.Windows.Forms.TextBox();
            this.launchAngleText = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.backgroundPanel2 = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            this.buttonPanel.SuspendLayout();
            this.backgroundPanel.SuspendLayout();
            this.backgroundPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            this.fileToolStripMenuItem.Click += new System.EventHandler(this.fileToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(93, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(884, 24);
            this.menuStrip1.TabIndex = 11;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.goalMissionToolStripMenuItem,
            this.groupInformationToolStripMenuItem,
            this.extraQuestionsToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // goalMissionToolStripMenuItem
            // 
            this.goalMissionToolStripMenuItem.Name = "goalMissionToolStripMenuItem";
            this.goalMissionToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.goalMissionToolStripMenuItem.Text = "Goal/Mission";
            this.goalMissionToolStripMenuItem.Click += new System.EventHandler(this.goalMissionToolStripMenuItem_Click);
            // 
            // groupInformationToolStripMenuItem
            // 
            this.groupInformationToolStripMenuItem.Name = "groupInformationToolStripMenuItem";
            this.groupInformationToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.groupInformationToolStripMenuItem.Text = "Group Information";
            this.groupInformationToolStripMenuItem.Click += new System.EventHandler(this.groupInformationToolStripMenuItem_Click);
            // 
            // extraQuestionsToolStripMenuItem
            // 
            this.extraQuestionsToolStripMenuItem.Name = "extraQuestionsToolStripMenuItem";
            this.extraQuestionsToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.extraQuestionsToolStripMenuItem.Text = "Extra Questions";
            this.extraQuestionsToolStripMenuItem.Click += new System.EventHandler(this.extraQuestionsToolStripMenuItem_Click);
            // 
            // startButton
            // 
            this.startButton.BackColor = System.Drawing.Color.Green;
            this.startButton.ForeColor = System.Drawing.SystemColors.Control;
            this.startButton.Location = new System.Drawing.Point(3, 1);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(103, 75);
            this.startButton.TabIndex = 12;
            this.startButton.Text = "Start";
            this.startButton.UseVisualStyleBackColor = false;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.BackColor = System.Drawing.Color.Red;
            this.exitButton.ForeColor = System.Drawing.SystemColors.Control;
            this.exitButton.Location = new System.Drawing.Point(112, 1);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(103, 75);
            this.exitButton.TabIndex = 13;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = false;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // heightOfLaunchText
            // 
            this.heightOfLaunchText.AutoSize = true;
            this.heightOfLaunchText.Location = new System.Drawing.Point(18, 6);
            this.heightOfLaunchText.Name = "heightOfLaunchText";
            this.heightOfLaunchText.Size = new System.Drawing.Size(130, 16);
            this.heightOfLaunchText.TabIndex = 0;
            this.heightOfLaunchText.Text = "Height of Launch (m):";
            // 
            // heightOfLaunchBox
            // 
            this.heightOfLaunchBox.Location = new System.Drawing.Point(21, 31);
            this.heightOfLaunchBox.Name = "heightOfLaunchBox";
            this.heightOfLaunchBox.Size = new System.Drawing.Size(125, 22);
            this.heightOfLaunchBox.TabIndex = 0;
            // 
            // speedOutputText
            // 
            this.speedOutputText.AutoSize = true;
            this.speedOutputText.Location = new System.Drawing.Point(211, 6);
            this.speedOutputText.Name = "speedOutputText";
            this.speedOutputText.Size = new System.Drawing.Size(77, 16);
            this.speedOutputText.TabIndex = 1;
            this.speedOutputText.Text = "Speed (kph):";
            // 
            // speedOutputBox
            // 
            this.speedOutputBox.Location = new System.Drawing.Point(214, 31);
            this.speedOutputBox.Name = "speedOutputBox";
            this.speedOutputBox.Size = new System.Drawing.Size(125, 22);
            this.speedOutputBox.TabIndex = 2;
            // 
            // launchAngleOutputText
            // 
            this.launchAngleOutputText.AutoSize = true;
            this.launchAngleOutputText.Location = new System.Drawing.Point(18, 73);
            this.launchAngleOutputText.Name = "launchAngleOutputText";
            this.launchAngleOutputText.Size = new System.Drawing.Size(124, 16);
            this.launchAngleOutputText.TabIndex = 3;
            this.launchAngleOutputText.Text = "Launch Angle (deg): ";
            // 
            // launchAngleBoxOutputBox
            // 
            this.launchAngleBoxOutputBox.Location = new System.Drawing.Point(21, 92);
            this.launchAngleBoxOutputBox.Name = "launchAngleBoxOutputBox";
            this.launchAngleBoxOutputBox.Size = new System.Drawing.Size(125, 22);
            this.launchAngleBoxOutputBox.TabIndex = 4;
            // 
            // massOfPodText
            // 
            this.massOfPodText.AutoSize = true;
            this.massOfPodText.Location = new System.Drawing.Point(211, 73);
            this.massOfPodText.Name = "massOfPodText";
            this.massOfPodText.Size = new System.Drawing.Size(80, 16);
            this.massOfPodText.TabIndex = 5;
            this.massOfPodText.Text = "Mass of Pod (kg):";
            // 
            // massOfPodBox
            // 
            this.massOfPodBox.Location = new System.Drawing.Point(214, 92);
            this.massOfPodBox.Name = "massOfPodBox";
            this.massOfPodBox.Size = new System.Drawing.Size(125, 22);
            this.massOfPodBox.TabIndex = 6;
            // 
            // totalAverageForceText
            // 
            this.totalAverageForceText.AutoSize = true;
            this.totalAverageForceText.Location = new System.Drawing.Point(18, 142);
            this.totalAverageForceText.Name = "totalAverageForceText";
            this.totalAverageForceText.Size = new System.Drawing.Size(125, 16);
            this.totalAverageForceText.TabIndex = 6;
            this.totalAverageForceText.Text = "Total Average Force (N):";
            // 
            // totalAverageForceBox
            // 
            this.totalAverageForceBox.Location = new System.Drawing.Point(21, 161);
            this.totalAverageForceBox.Name = "totalAverageForceBox";
            this.totalAverageForceBox.Size = new System.Drawing.Size(125, 22);
            this.totalAverageForceBox.TabIndex = 7;
            // 
            // groundContactText
            // 
            this.groundContactText.AutoSize = true;
            this.groundContactText.Location = new System.Drawing.Point(211, 142);
            this.groundContactText.Name = "groundContactText";
            this.groundContactText.Size = new System.Drawing.Size(137, 16);
            this.groundContactText.TabIndex = 8;
            this.groundContactText.Text = "Ground Contact Angle (deg):";
            // 
            // groundContactBox
            // 
            this.groundContactBox.Location = new System.Drawing.Point(214, 161);
            this.groundContactBox.Name = "groundContactBox";
            this.groundContactBox.Size = new System.Drawing.Size(125, 22);
            this.groundContactBox.TabIndex = 9;
            // 
            // successfulDeliveryText
            // 
            this.successfulDeliveryText.AutoSize = true;
            this.successfulDeliveryText.Location = new System.Drawing.Point(128, 220);
            this.successfulDeliveryText.Name = "successfulDeliveryText";
            this.successfulDeliveryText.Size = new System.Drawing.Size(115, 16);
            this.successfulDeliveryText.TabIndex = 10;
            this.successfulDeliveryText.Text = "Sucessful Delivery?";
            // 
            // sucessfulDeliveryBox
            // 
            this.sucessfulDeliveryBox.Location = new System.Drawing.Point(131, 239);
            this.sucessfulDeliveryBox.Name = "sucessfulDeliveryBox";
            this.sucessfulDeliveryBox.Size = new System.Drawing.Size(128, 22);
            this.sucessfulDeliveryBox.TabIndex = 11;
            // 
            // dynamicLabel
            // 
            this.dynamicLabel.AutoSize = true;
            this.dynamicLabel.Location = new System.Drawing.Point(-3, 27);
            this.dynamicLabel.Name = "dynamicLabel";
            this.dynamicLabel.Size = new System.Drawing.Size(77, 16);
            this.dynamicLabel.TabIndex = 10;
            this.dynamicLabel.Text = "seriesofmsgs";
            // 
            // buttonPanel
            // 
            this.buttonPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.buttonPanel.Controls.Add(this.startButton);
            this.buttonPanel.Controls.Add(this.exitButton);
            this.buttonPanel.Location = new System.Drawing.Point(497, 366);
            this.buttonPanel.Margin = new System.Windows.Forms.Padding(5);
            this.buttonPanel.Name = "buttonPanel";
            this.buttonPanel.Size = new System.Drawing.Size(225, 82);
            this.buttonPanel.TabIndex = 16;
            // 
            // speedText
            // 
            this.speedText.AutoSize = true;
            this.speedText.Location = new System.Drawing.Point(48, 8);
            this.speedText.Name = "speedText";
            this.speedText.Size = new System.Drawing.Size(77, 16);
            this.speedText.TabIndex = 9;
            this.speedText.Text = "Speed (kph):";
            // 
            // speedBox
            // 
            this.speedBox.AccessibleDescription = "";
            this.speedBox.AccessibleName = "Speed";
            this.speedBox.Location = new System.Drawing.Point(128, 5);
            this.speedBox.Name = "speedBox";
            this.speedBox.Size = new System.Drawing.Size(96, 22);
            this.speedBox.TabIndex = 2;
            // 
            // dropHeightBox
            // 
            this.dropHeightBox.AccessibleName = "Drop Height";
            this.dropHeightBox.Location = new System.Drawing.Point(128, 41);
            this.dropHeightBox.Name = "dropHeightBox";
            this.dropHeightBox.Size = new System.Drawing.Size(96, 22);
            this.dropHeightBox.TabIndex = 4;
            this.dropHeightBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dropHeightBox_KeyDown);
            this.dropHeightBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dropHeightBox_KeyPress);
            // 
            // dropHeightText
            // 
            this.dropHeightText.AutoSize = true;
            this.dropHeightText.Location = new System.Drawing.Point(23, 44);
            this.dropHeightText.Name = "dropHeightText";
            this.dropHeightText.Size = new System.Drawing.Size(102, 16);
            this.dropHeightText.TabIndex = 1;
            this.dropHeightText.Text = "Drop Height (m):";
            // 
            // backgroundPanel
            // 
            this.backgroundPanel.BackColor = System.Drawing.Color.Transparent;
            this.backgroundPanel.Controls.Add(this.launchAngleBox);
            this.backgroundPanel.Controls.Add(this.launchAngleText);
            this.backgroundPanel.Controls.Add(this.dropHeightText);
            this.backgroundPanel.Controls.Add(this.dropHeightBox);
            this.backgroundPanel.Controls.Add(this.speedBox);
            this.backgroundPanel.Controls.Add(this.speedText);
            this.backgroundPanel.Location = new System.Drawing.Point(12, 146);
            this.backgroundPanel.Name = "backgroundPanel";
            this.backgroundPanel.Size = new System.Drawing.Size(252, 245);
            this.backgroundPanel.TabIndex = 10;
            this.backgroundPanel.Visible = false;
            // 
            // launchAngleBox
            // 
            this.launchAngleBox.AccessibleName = "Launch Angle";
            this.launchAngleBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.launchAngleBox.Location = new System.Drawing.Point(128, 76);
            this.launchAngleBox.Name = "launchAngleBox";
            this.launchAngleBox.Size = new System.Drawing.Size(96, 22);
            this.launchAngleBox.TabIndex = 11;
            this.launchAngleBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.launchAngleBox_KeyDown);
            this.launchAngleBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.launchAngleBox_KeyPress);
            // 
            // launchAngleText
            // 
            this.launchAngleText.AutoSize = true;
            this.launchAngleText.Location = new System.Drawing.Point(4, 79);
            this.launchAngleText.Name = "launchAngleText";
            this.launchAngleText.Size = new System.Drawing.Size(121, 16);
            this.launchAngleText.TabIndex = 10;
            this.launchAngleText.Text = "Launch Angle (deg):";
            // 
            // calculateButton
            // 
            this.calculateButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.calculateButton.Location = new System.Drawing.Point(19, 311);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(217, 62);
            this.calculateButton.TabIndex = 17;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = false;
            this.calculateButton.Visible = false;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // backgroundPanel2
            // 
            this.backgroundPanel2.BackColor = System.Drawing.Color.Transparent;
            this.backgroundPanel2.Controls.Add(this.launchAngleBoxOutputBox);
            this.backgroundPanel2.Controls.Add(this.sucessfulDeliveryBox);
            this.backgroundPanel2.Controls.Add(this.heightOfLaunchText);
            this.backgroundPanel2.Controls.Add(this.successfulDeliveryText);
            this.backgroundPanel2.Controls.Add(this.heightOfLaunchBox);
            this.backgroundPanel2.Controls.Add(this.groundContactBox);
            this.backgroundPanel2.Controls.Add(this.speedOutputText);
            this.backgroundPanel2.Controls.Add(this.groundContactText);
            this.backgroundPanel2.Controls.Add(this.speedOutputBox);
            this.backgroundPanel2.Controls.Add(this.totalAverageForceBox);
            this.backgroundPanel2.Controls.Add(this.launchAngleOutputText);
            this.backgroundPanel2.Controls.Add(this.totalAverageForceText);
            this.backgroundPanel2.Controls.Add(this.massOfPodText);
            this.backgroundPanel2.Controls.Add(this.massOfPodBox);
            this.backgroundPanel2.Location = new System.Drawing.Point(434, 27);
            this.backgroundPanel2.Name = "backgroundPanel2";
            this.backgroundPanel2.Size = new System.Drawing.Size(425, 326);
            this.backgroundPanel2.TabIndex = 18;
            this.backgroundPanel2.Visible = false;
            // 
            // Form1
            // 
            this.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlText;
            this.BackgroundImage = global::NASAFormApplication.Properties.Resources.NASA;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(884, 512);
            this.Controls.Add(this.backgroundPanel2);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.dynamicLabel);
            this.Controls.Add(this.buttonPanel);
            this.Controls.Add(this.backgroundPanel);
            this.Controls.Add(this.menuStrip1);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Font = new System.Drawing.Font("Times New Roman", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "NASA Project";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.buttonPanel.ResumeLayout(false);
            this.backgroundPanel.ResumeLayout(false);
            this.backgroundPanel.PerformLayout();
            this.backgroundPanel2.ResumeLayout(false);
            this.backgroundPanel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }



        #endregion

        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem goalMissionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem groupInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem extraQuestionsToolStripMenuItem;
        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label dynamicLabel;
        private System.Windows.Forms.Panel buttonPanel;
        private System.Windows.Forms.Label speedText;
        private System.Windows.Forms.TextBox speedBox;
        private System.Windows.Forms.TextBox dropHeightBox;
        private System.Windows.Forms.Label dropHeightText;
        private System.Windows.Forms.Panel backgroundPanel;
        private System.Windows.Forms.TextBox heightOfLaunchBox;
        private System.Windows.Forms.Label heightOfLaunchText;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Label launchAngleText;
        private System.Windows.Forms.TextBox launchAngleBox;
        private System.Windows.Forms.Label speedOutputText;
        private System.Windows.Forms.TextBox speedOutputBox;
        private System.Windows.Forms.Label launchAngleOutputText;
        private System.Windows.Forms.TextBox launchAngleBoxOutputBox;
        private System.Windows.Forms.Label massOfPodText;
        private System.Windows.Forms.TextBox massOfPodBox;
        private System.Windows.Forms.Label totalAverageForceText;
        private System.Windows.Forms.TextBox totalAverageForceBox;
        private System.Windows.Forms.Label groundContactText;
        private System.Windows.Forms.TextBox groundContactBox;
        private System.Windows.Forms.Label successfulDeliveryText;
        private System.Windows.Forms.TextBox sucessfulDeliveryBox;
        private System.Windows.Forms.Panel backgroundPanel2;

    }

}